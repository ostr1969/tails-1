
document.addEventListener("DOMContentLoaded", () => {
  
  PDFViewerApplication.initializedPromise.then(() => {

    // --- 1. Parse words from URL ---
    const params = new URLSearchParams(window.location.search);
    const words = (params.get("words") || "")
      .split(",")
      .map(w => w.trim())
      .filter(Boolean);

    if (!words.length) return;

    // --- 2. Define dark colors ---
    const COLORS = [
      "#c62828", // dark red
      "#6a1b9a", // dark purple
      "#1565c0", // dark blue
      "#2e7d32", // dark green
      "#ef6c00", // dark orange
      "#4e342e"  // dark brown
    ];

    // --- 3. Assign a random color per word ---
    const wordColor = {};
    for (const w of words) {
      wordColor[w.toLowerCase()] = COLORS[Math.floor(Math.random() * COLORS.length)];
    }

    // --- 4. Build regex to match any word ---
    const escaped = words.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    const regex = new RegExp(`\\b(${escaped.join("|")})\\b`, "gi");
    console.log("Highlighting words:", words, regex);
    // --- 5. Track pages already highlighted ---
    const seenPages = new Set();

    // --- 6. Highlight function per page ---
    const highlightPage = ({ pageNumber }) => {
      if (seenPages.has(pageNumber)) return; // already done
      seenPages.add(pageNumber);
      console.log("Highlighting page:", pageNumber);
      const page = document.querySelector(`.page[data-page-number="${pageNumber}"]`);
      
      if (!page) return;
      //console.log("Processing page element:", page);
      const prevpage = document.querySelector(`.page[data-page-number="${pageNumber-1}"]`);
 //const spans = prevpage.querySelectorAll(".textLayer span");
   //console.log("Found prevspans:", spans.length);

      prevpage.querySelectorAll(".textLayer span").forEach(span => {
       // console.log("Checking span text:", span.textContent);
        const text = span.textContent;
        let match;
        
        while ((match = regex.exec(text)) !== null) {
          const key = match[0].toLowerCase();
          span.style.backgroundColor = wordColor[key];
        }
      });

      // Stop listener if all pages processed
      if (seenPages.size === PDFViewerApplication.pagesCount) {
        PDFViewerApplication.eventBus.off("pagerendered", highlightPage);
      }
    };


    // --- 7. Attach listener ---
    PDFViewerApplication.eventBus.on("pagerendered", highlightPage);

    // --- 8. Highlight already rendered page (first page) ---
    highlightPage({ pageNumber: PDFViewerApplication.page });
  });

});